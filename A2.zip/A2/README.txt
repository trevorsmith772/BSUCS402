Trevor Smith
CS 402 - A2
October 2, 2021

This app was definitely a bigger challenge. Unfortunately I was not able to get my split function to work, but I was successful with my add, delete, and join buttons. It was difficult for me to decide how to join two items in a list, but ultimately I decided to concatenate them. I decided to do this because I couldn't really think of a real application for why I would join two items in a list, so I decided to keep it simple with a basic concatenation.