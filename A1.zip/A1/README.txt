Trevor Smith
CS 402 - A1
September 9, 2021

This app is pretty simple. As far as design decisions, I decided to center my button and all text on the device. I feel like centering the button helps the program scale with different sized displays. Nothing in this assignment was very difficult, but I can tell it can become much harder when developing a little more complex applications. I decided to name this program HelloWorld, since it’s the first app being developed in this class, and it’s tradition in the CS world.